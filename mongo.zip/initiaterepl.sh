echo "************** initiaterepl.sh start ********************";
server=$1;

if [ ! -z "$server" ]
      then
  echo "**********  AddNode Start ***************";
  echo "rs.add({host:"'"'$server':27017"});' >> /tmp/initiaterepl3.js;
  echo "************** addreplnode end ********************";

else
  #echo "use admin;" >> /tmp/initiaterepl1.js;
  #echo "db.shutdownServer()" >> /tmp/initiaterepl1.js;
  #echo "exit;" >> /tmp/initiaterepl1.js;
  echo "use admin;" >> /tmp/initiaterepl2.js;
  echo "rs.initiate();" >> /tmp/initiaterepl2.js;
  echo "rs.status();" >> /tmp/initiaterepl2.js;
  echo "exit;" >> /tmp/initiaterepl2.js;
fi;
echo "************** initiaterepl.sh end ********************";
