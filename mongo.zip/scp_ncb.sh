echo "************** scp_ncb.sh start ********************";
server=$1;
user=$2;
pwd=$3;
file=$4;
echo "*** copying file $file to server $server ***";
echo "sudo sshpass -p $pwd scp -o StrictHostKeyChecking=no $file $user@$server:/tmp;";
sudo sshpass -p $pwd scp -o StrictHostKeyChecking=no $file $user@$server:/tmp;
echo "************** scp_ncb.sh end ********************";
