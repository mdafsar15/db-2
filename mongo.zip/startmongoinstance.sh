server=$1;
port=$2;
authflag=$3;

pkill mongod;
while [ ture ]
do
 if pgrep -x "mongod" > /dev/null; then
   echo "MongoD Process Running";
   sleep 5;
 else
   if [ -z "$server" ]
    then
    echo "mongod --dbpath /var/lib/mongo --logpath /var/log/mongodb/mongod.log --fork";
    sudo mongod --dbpath /var/lib/mongo --logpath /var/log/mongodb/mongod.log --fork;
   else
    if [ -z "$authflag" ]
     then
     echo "sudo mongod --port $port --dbpath /var/lib/mongo --logpath /var/log/mongodb/mongod.log --replSet rep0 --fork  --bind_ip $server";
     sudo mongod --port $port --dbpath /var/lib/mongo --logpath /var/log/mongodb/mongod.log --replSet rep0 --fork  --bind_ip $server;
    else
     echo "mongod --auth --port $port --dbpath /var/lib/mongo --logpath /var/log/mongodb/mongod.log --replSet rep0 --fork --keyFile /var/lib/mongokey/key --bind_ip $server";
     sudo mongod --auth --port $port --dbpath /var/lib/mongo --logpath /var/log/mongodb/mongod.log --replSet rep0 --fork --keyFile /var/lib/mongokey/key --bind_ip $server;
    fi;
   fi;
   exit;
  fi;
done;
